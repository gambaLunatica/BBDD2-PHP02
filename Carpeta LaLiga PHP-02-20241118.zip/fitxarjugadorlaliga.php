<?php session_start(); ?>
<html>
<body>
<center><a href="identifica.php"><img src="logolaliga.png" width="75"></a>
<br>
<br>Mostrar llista de jugadors que no són de l'equip
<br>Cada jugador ha de tenir una opció de FITXAR que canviï l'equip del jugador
</center>
<meta http-equiv="refresh" content="30; url=identifica.php">
</body>
</html>